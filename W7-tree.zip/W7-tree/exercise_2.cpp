#include <iostream>
#include <time.h>
#include <math.h>
#include "BinaryTree.h"
#include "Node.h"

int generateARandomDirection() {
    return rand() % 2;
}

void insertValueOn(Node* node, int value) {
    int direction = generateARandomDirection();
    if (direction == 0){
        if (node->left != nullptr) {
            insertValueOn(node->left, value);
        } else {
            node->left = new Node(value);
        }
    } else {
        if (node->right != nullptr) {
            insertValueOn(node->right, value);
        } else {
            node->right = new Node(value);
        }
    }
}

Node* generateTree(Node* node) {
    int randomValue = rand() % 100;
    insertValueOn(node, randomValue);
    return node;
}

void toString(Node* node, std::string& result, int level) {
    if (node != nullptr) {
        for (int i = 1; i <= level; i++) {
            result += (i == level) ? "|_" : "|  ";
        }
        result += std::to_string(node->data) + "\n";
        level++;
        toString(node->left, result, level);
        toString(node->right, result, level);
    }
}

int calculateHeight(Node* node) {
    if (node == nullptr) return -1;
    int heightLeft = calculateHeight(node->left);
    int heightRight = calculateHeight(node->right);
    return 1 + std::max(heightLeft, heightRight);   
}

int main() {
    //1.  Create a binary Tree
    //2.  Randomly generate 50 numbers
    //3.  Insert each number into the tree
    //4.    Print a tree result
    //5.    Challenge: Implement a function that returns the height of the tree
    srand(time(0));
    int randomRoot = rand() % 100;

    BinaryTree tree(randomRoot);
    Node* root = tree.getRoot();

    for (int i = 1; i < 50; i++) {
        root = generateTree(root);
    }
    
    std::string result = "";
    std::cout << "Pre-Order Traversal: " << tree.preOrderTraverse() << std::endl;
    toString(root, result, 0);
    std::cout << "\nBinary Tree:\n" << result << std::endl;

    std::cout << "\nHeigh of tree: " << calculateHeight(root) << std::endl;
}